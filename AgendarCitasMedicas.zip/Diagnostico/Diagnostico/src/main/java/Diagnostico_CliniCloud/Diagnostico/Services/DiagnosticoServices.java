package Diagnostico_CliniCloud.Diagnostico.Services;

import jakarta.transaction.Transactional;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import Diagnostico_CliniCloud.Diagnostico.Model.Diagnostico;
import Diagnostico_CliniCloud.Diagnostico.Repository.DiagnosticoRepository;

@Service
@Transactional
public class DiagnosticoServices {

    @Autowired
    private DiagnosticoRepository diagnosticoRepository; // Repositorio para acceder a la base de datos de diagnósticos

    @Autowired
    private RestTemplate restTemplate; // Bean para realizar llamadas HTTP a servicios externos


    // URLs de microservicios externos
    
    @Value("${microservicio.citas.url}")
    private String citasUrl; // URL del microservicio de Citas, inyectada

    @Value("${microservicio.usuarios.url}")
    private String usuariosUrl; // URL del microservicio de usuarios, inyectada


    // Lista TODOS los diagnósticos en la base de datos
    public List<Diagnostico> listarDiagnosticos() {
        return diagnosticoRepository.findAll();
    }
    

    // Busca un diagnóstico por el RUN del paciente
    public Diagnostico buscarPorRun(String run) {
        return diagnosticoRepository.buscarPorRun(run);
    } 

    // Busca un diagnóstico por su ID único
    public Diagnostico buscarPorId(int id) {
        return diagnosticoRepository.findById(id).get();
    }

    // Guarda un nuevo diagnóstico o actualiza uno existente
    public Diagnostico save(Diagnostico diagnostico) {
        return diagnosticoRepository.save(diagnostico);
    }

    // Elimina un diagnóstico por su ID
    public void delete(int id) {
        diagnosticoRepository.deleteById(id);
    }

    /*
     * Metodos RestTemplate para obtener datos de otros microservicios
     * Estos métodos utilizan RestTemplate para realizar llamadas HTTP a otros microservicios
     * 
     * Se deben utilizar para obtener información adicional como por ejemplo el nombre y correo del paciente
     * Estos datos se obtienen a través de un microservicio de usuarios, que proporciona la información del paciente
     * mediante su RUN.
     */


    // // Plantillas de motodos:
    
    // Metodo para obtener Nombre mediante otro microservicio
    
    
    public String obtenerNombrePorRun(String run) {
    try {
        // Ajusta la URL para que apunte al endpoint correcto del microservicio de citas
        String url = citasUrl + "/" + run;
        CitasMedica cita = restTemplate.getForObject(url, CitasMedica.class);
        if (cita != null && cita.getNombre() != null) {
            return cita.getNombre();
        } else {
            return "Nombre no encontrado";
        }
    } catch (Exception e) {
        return "Nombre no encontrado";
    }
    


}
