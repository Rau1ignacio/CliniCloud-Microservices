package com.AgendarCitasMedicas.AgendarCitasMedicas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgendarCitasMedicasApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgendarCitasMedicasApplication.class, args);
		System.out.println("\n===========================================");
		System.out.println("     Citas CliniCloud Iniciado   ");
		System.out.println("===========================================\n");
	}

}
