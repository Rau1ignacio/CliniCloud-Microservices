package com.AgendarCitasMedicas.AgendarCitasMedicas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest(classes = AgendarCitasMedicasApplication.class)
class AgendarCitasMedicasApplicationTests {

	@Test
	void contextLoads() {
	}


}
