# CliniCloud-Microservices
Plataforma de salud digital desarrollada por CliniCloud Services con arquitectura basada en microservicios. Incluye funcionalidades como telemedicina, historial clínico, monitoreo remoto, recetas electrónicas, entre otras.
