package Diagnostico_CliniCloud.Diagnostico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiagnosticoApplicationTests {

	@Test
	void contextLoads() {
	}

}
